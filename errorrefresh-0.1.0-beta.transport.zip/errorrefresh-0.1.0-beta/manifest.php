<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => false,
    'license' => false,
    'readme' => false,
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a7f985c5b1d8417299d287536a6620b6',
      'native_key' => 'errorrefresh',
      'filename' => 'modNamespace/71267d893f0ea6a4fcaeeedc09342869.vehicle',
      'namespace' => 'errorrefresh',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '9b22d3abd5297cdb44a2e8e6ced8825e',
      'native_key' => 1,
      'filename' => 'modCategory/1317514f846c2154986536fc6dd38ebc.vehicle',
      'namespace' => 'errorrefresh',
    ),
  ),
);