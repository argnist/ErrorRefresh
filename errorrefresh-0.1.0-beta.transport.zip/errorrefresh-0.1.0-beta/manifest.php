<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => false,
    'license' => false,
    'readme' => false,
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '696ae02fc52bca45b837be828a72ab4c',
      'native_key' => 'errorrefresh',
      'filename' => 'modNamespace/d909051f3d74ea002aa7e06c931e3a88.vehicle',
      'namespace' => 'errorrefresh',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6061e8b23367fc0333498377795c4744',
      'native_key' => 1,
      'filename' => 'modCategory/0c5cf5f339c7b3a42da83728ca809825.vehicle',
      'namespace' => 'errorrefresh',
    ),
  ),
);