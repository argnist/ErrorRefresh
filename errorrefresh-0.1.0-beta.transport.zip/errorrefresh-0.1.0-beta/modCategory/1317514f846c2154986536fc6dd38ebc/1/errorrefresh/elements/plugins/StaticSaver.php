<?php

if ($modx->event->name == '') {

}
